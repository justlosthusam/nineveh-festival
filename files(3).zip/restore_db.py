#!/usr/bin/env python3
"""يعيد بناء db.json من recovered_bookings.csv (المستخرج من رسائل بوت التلكرام).

الاستخدام:
    python restore_db.py                       # كل الحجوزات = بانتظار الموافقة
    python restore_db.py --approved ids.txt    # ids.txt: رقم حجز في كل سطر ليصبح معتمداً
    python restore_db.py --keep-test           # إبقاء حجز الاختبار NIFF2-TEST101

قاعدة التعارض: الأقدم وقتاً يحتفظ بالمقعد. الحجز المتأخر يُعلَّم conflict=true
ولا يستحوذ على المقعد المتنازع عليه حتى تقرر إدارياً.
"""
import argparse, csv, json, os, re, sys
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import server_layout as L   # نفس تكوين المقاعد الموجود في server.py

ap = argparse.ArgumentParser()
ap.add_argument("--csv", default="recovered_bookings.csv")
ap.add_argument("--out", default="db.json")
ap.add_argument("--approved", help="ملف نصي فيه أرقام الحجوزات المعتمدة")
ap.add_argument("--keep-test", action="store_true")
a = ap.parse_args()

approved = set()
if a.approved:
    approved = {x.strip().upper() for x in open(a.approved, encoding="utf-8") if x.strip()}

rows = list(csv.DictReader(open(a.csv, encoding="utf-8-sig")))
rows.sort(key=lambda r: (r["time"], r["booking_id"]))
if not a.keep_test:
    rows = [r for r in rows if "TEST" not in r["booking_id"]]

data = L.fresh_db()
seat_by_code = {s["code"]: s for s in data["seats"]}
bookings, conflicts, unknown = [], [], []

for r in rows:
    bid = r["booking_id"].strip()
    codes = [c.strip() for c in r["seats"].split(",") if c.strip()]
    st = "approved" if bid.upper() in approved else "pending_approval"
    name, cat = r["name"].strip(), r["type"].strip()
    bk = {
        "id": bid, "name": name, "phone": r["phone_raw"].strip(),
        "category": cat, "organization": "", "personsCount": len(codes),
        "seatCodes": codes, "attendees": [], "status": st,
        "createdAt": datetime.strptime(r["time"], "%Y-%m-%d %H:%M:%S").isoformat(),
        "qrCodeData": f"NIFF2|{bid}|{name}|{cat}|{','.join(codes)}",
        "restored": True,
    }
    lost = []
    for c in codes:
        s = seat_by_code.get(c)
        if not s: unknown.append((bid, c)); continue
        if s["bookingId"] and s["bookingId"] != bid:
            lost.append(c)
        else:
            s["status"] = "reserved" if st == "approved" else "pending"
            s["bookingId"] = bid
    if lost:
        bk["conflict"] = True
        bk["conflictSeats"] = lost
        for c in lost:
            conflicts.append({"seat": c, "winner": seat_by_code[c]["bookingId"], "loser": bid})
    bookings.append(bk)

data["bookings"] = bookings
json.dump(data, open(a.out, "w", encoding="utf-8"), ensure_ascii=False, indent=2)

with open("conflict_report.csv", "w", encoding="utf-8-sig", newline="") as f:
    w = csv.DictWriter(f, fieldnames=["seat", "winner", "loser"]); w.writeheader(); w.writerows(conflicts)

taken = sum(1 for s in data["seats"] if s["bookingId"])
print(f"الحجوزات المستعادة : {len(bookings)}")
print(f"المقاعد المشغولة   : {taken} من {len(data['seats'])}")
print(f"حجوزات فيها تعارض  : {sum(1 for b in bookings if b.get('conflict'))}  (انظر conflict_report.csv)")
print(f"المعتمدة           : {sum(1 for b in bookings if b['status']=='approved')}")
if unknown: print("مقاعد غير معروفة:", unknown)
print("->", a.out)
