"""تكوين المقاعد منسوخ حرفياً من server.py"""
ORGANIZER_EMAIL = "husamalsiayd@gmail.com"
THEATER_BLOCKS = [
    {"id": "B", "rows": [{"row": 1, "count": 10}, {"row": 2, "count": 11}, {"row": 3, "count": 11}, {"row": 4, "count": 12}, {"row": 5, "count": 12}, {"row": 6, "count": 13}, {"row": 7, "count": 13}, {"row": 8, "count": 14}, {"row": 9, "count": 14}]},
    {"id": "C", "rows": [{"row": 1, "count": 10}, {"row": 2, "count": 10}, {"row": 3, "count": 11}, {"row": 4, "count": 12}, {"row": 5, "count": 12}, {"row": 6, "count": 13}, {"row": 7, "count": 13}, {"row": 8, "count": 14}, {"row": 9, "count": 15}]},
    {"id": "D", "rows": [{"row": 1, "count": 13}, {"row": 2, "count": 13}, {"row": 3, "count": 13}, {"row": 4, "count": 13}, {"row": 5, "count": 13}, {"row": 6, "count": 13}, {"row": 7, "count": 13}, {"row": 8, "count": 13}, {"row": 9, "count": 13}]},
    {"id": "E", "rows": [{"row": 1, "count": 20}, {"row": 2, "count": 19}, {"row": 3, "count": 19}, {"row": 4, "count": 19}, {"row": 5, "count": 18}, {"row": 6, "count": 18}, {"row": 7, "count": 17}, {"row": 8, "count": 17}, {"row": 9, "count": 16}, {"row": 10, "count": 16}]},
    {"id": "F", "rows": [{"row": 1, "count": 13}, {"row": 2, "count": 13}, {"row": 3, "count": 13}, {"row": 4, "count": 13}, {"row": 5, "count": 13}, {"row": 6, "count": 13}, {"row": 7, "count": 13}, {"row": 8, "count": 13}, {"row": 9, "count": 13}]}
]
OUTDOOR_TOTAL = 4000

def fresh_db():
    seats = []
    seat_id_counter = 1
    for b in THEATER_BLOCKS:
        for r in b["rows"]:
            for s in range(1, r["count"] + 1):
                seats.append({
                    "id": seat_id_counter,
                    "code": f"{b['id']}-{r['row']}-{s}",
                    "block": b["id"],
                    "row": r["row"],
                    "number": s,
                    "type": "theater",
                    "status": "available",
                    "bookingId": None
                })
                seat_id_counter += 1
    for i in range(1, OUTDOOR_TOTAL + 1):
        seats.append({
            "id": seat_id_counter,
            "code": f"\u0635\u064a\u0641\u064a-{i}",
            "block": "\u0635\u064a\u0641\u064a",
            "row": (i - 1) // 80 + 1,
            "number": i,
            "type": "outdoor",
            "status": "available",
            "bookingId": None
        })
        seat_id_counter += 1
    data = {
        "seats": seats,
        "bookings": [],
        "config": {
            "organizerEmail": ORGANIZER_EMAIL,
            "festivalName": "\u0645\u0647\u0631\u062c\u0627\u0646 \u0646\u064a\u0646\u0648\u0649 \u0627\u0644\u0633\u064a\u0646\u0645\u0627\u0626\u064a \u0627\u0644\u062f\u0648\u0644\u064a - \u0627\u0644\u062f\u0648\u0631\u0629 \u0627\u0644\u062b\u0627\u0646\u064a\u0629",
            "blockTotals": {"B": 110, "C": 110, "D": 117, "E": 179, "F": 117},
            "outdoorTotal": OUTDOOR_TOTAL
        }
    }
    return data
